<?php
	$conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
?>