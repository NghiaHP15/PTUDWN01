<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:signin.php');
}
try{
    $conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
    echo 'Connection success';
}
catch (PDOException $e){
    echo 'Connection failed';
}

$sinhviens = ['STT','ID', 'Nhan vien id', 'trang thai', 'nguoinhan', 'dien thoai', 'diachi', 'ngaygiaohang','ghi chu'];
    $sql = "SELECT * FROM vandon";
    $stmt = $conn->prepare($sql);
    $query = $stmt->execute();
    $result = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $result[] = $row;
    }
if(!empty($_POST['search'])){
    $timkiem = $_POST['search'];
    $sql = "SELECT * FROM vandon WHERE nguoinhan LIKE '%$timkiem%'";
    $stmt = $conn->prepare($sql);
    $query = $stmt->execute();
    $result = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $result[] = $row;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>QUẢN LÝ VẬN ĐƠN - BUI MINH NGHIA - 86986</title>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-3.5.1.slim.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="container p-4 text-uppercase ">
    <div class="header text-center">
        <h1 style="font-size: 20px; font-weight: bold ">Quan ly van don</h1>
    </div>
    <div class="boder">
        <ul class="nav align-items-center p-2 justify-content-between pl-4 pr-4 bg-light">
            <li class="logo" >
                <a><img src="images/logo.png" style="height: 50px; width: 50px"/></a>
            </li>
            <li class="nav-item"><a href="index.php" style="color: gray; font-size: 16px; font-weight: 600">Trang chu</a></li>
            <li class="nav-item"><a href="list.php" style="color: gray; font-size: 16px; font-weight: 600">Ds van don</a></li>
            <li class="nav-item"><a href="cau1.png" style="color: gray; font-size: 16px; font-weight: 600">Anh cau 1</a></li>
            <li class="nav-item"><a href="signout.php" style="color: gray; font-size: 16px; font-weight: 600">Dang xuat</a></li>
        </ul>
        <div class="pt-4 pb-4">
            <form method="post">
                <div class="input-group mb-2">
                    <input placeholder="Ten nhan vien ..." name="search" id="name" class="form-control" />
                    <input type="submit" value="Search" name="submit" class="btn btn-dark pl-5 pr-5">
                </div>
            </form>
        </div>
        <div class="table-sv">
            <table class="table table-striped">
                <thead class="thead-dark">
                <tr>
                    <?php foreach ($sinhviens as $item):?>
                        <th>
                            <?=$item?>
                        </th>
                    <?php endforeach; ?>
                </tr>
                <tbody>
                <?php $i=1; foreach ($result as $item):?>
                    <tr>
                        <th><?=$i?></th>
                        <th><?=$item['ID']?></th>
                        <th><?=$item['nhanvien_ID']?></th>
                        <th><?=$item['trangthai']?></th>
                        <th><?=$item['nguoinhan']?></th>
                        <th><?=$item['dienthoai']?></th>
                        <th><?=$item['diachi']?></th>
                        <th><?=$item['ngaygiaohang']?></th>
                        <th><?=$item['ghichu']?></th>
                    </tr>
                    <?php $i++; endforeach; ?>
                </tbody>
                </thead>
            </table>
        </div>
        <div class="footer">
            <p>Xin chao <?= $_SESSION['username']?></p>
            <p>Xin chao ban dang nhap vao luc <?=$_SESSION['datetime']?> </p>
        </div>
    </div>
</div>
</body>
</html>
