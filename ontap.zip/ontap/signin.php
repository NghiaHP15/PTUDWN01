<?php
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
try{
    $conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
    echo 'Connection success';
}
catch (PDOException $e){
    echo 'Connection failed';
}
if(!empty($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM user WHERE username = '$username' AND matkhau = '$password'";
    $stmt = $conn->prepare($sql);
    $query = $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row){
        $_SESSION['username'] = $username;
        $_SESSION['datetime'] = date('d/m/y H:i:s');
        header('location:index.php');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Trang Đăng Nhập</title>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-3.5.1.slim.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header>QUẢN LÝ VẬN ĐƠN</header>
    <div class="container p-4 text-uppercase position-relative">
        <div class="login ">
            <h1 class="signUp font-weight-bold">Login</h1>
            <form method="post">
                <div class="input-group pt-4">
                    <input name="username" type="text" placeholder="Username" class="form-control p-4" id="username">
                </div>
                <div class="input-group pt-4">
                    <input name="password" type="password" placeholder="Password" class="form-control p-4" id="password">
                </div>
                <div class="input-group pt-4">
                    <input name="submit" type="submit" class="btn btn-blue pl-5 pt-2 pb-2 pl-2 pr-5 text-uppercase font-weight-bold" value="Log In" >
                </div>
            </form>
        </div>
    </div>
</body>
</html>
